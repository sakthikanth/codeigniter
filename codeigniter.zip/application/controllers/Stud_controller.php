<?php 
   class Stud_controller extends CI_Controller {
	   
	 
	
      function __construct() { 
         parent::__construct(); 
		  
         $this->load->helper('url'); 
         $this->load->database(); 
      } 
  
      public function index() { 
         $query = $this->db->get("test"); 
         $data['records'] = $query->result(); 
			
         $this->load->helper('url'); 
         $this->load->view('Stud_view',$data); 
      } 
  
      public function add_student_view() { 
         $this->load->helper('form'); 
         $this->load->view('Stud_add'); 
      } 
	  
	  public function show_student(){
	  $this->load->helper('form'); 
	  $this->load->model('Stud_Model');
	  
	  $data['records']=$this->Stud_Model->get_this('test');
	  
         $this->load->view('Stud_view',$data); 
	  
	  }
  
      public function add_student() { 
         $this->load->model('Stud_Model');
			
			
         $data = array( 
            'u_name' => $this->input->post('user_name'), 
            'u_pass' => $this->input->post('user_pass') 
         ); 
			$tbl="test";
         $this->Stud_Model->ins_q($data,"test"); 
   
         $data['records'] =$this->Stud_Model->get_this($tbl); 
         $this->load->view('Stud_view',$data); 
      } 
  
      public function update_student_view() {

			$this->load->model('Stud_Model');
         $this->load->helper('form'); 
         $user_id =$this->uri->segment('3'); 
		 $tbl="test";
		 $arr=array('id'=>$user_id);
		 
         $data['records'] = $this->Stud_Model->get_where($tbl,$arr); 
        if($data['records']!=null){
		 $this->load->view('Stud_edit',$data); 
		}else{
			echo "no user found";
		}
        
      } 
  
      public function update_student(){

	  	$tbl="test";
         $this->load->model('Stud_Model');
		 $this->load->helper('form');
			$username=$this->input->post('userpass');
			$password=$this->input->post('userpass');
			if($username!=null && $password!=null){
				   $data = array( 
            'u_name' => $this->input->post('username'), 
            'u_pass' => $this->input->post('userpass') 
         ); 
			
			 $this->load->helper('form');
			$user_id=$this->uri->segment('3');
					
		
		 $whre=array('id'=>$user_id);
         $this->Stud_Model->update_where($data,$whre,$tbl); 
			}
      
			
         $data['records'] = $this->Stud_Model->get_this($tbl); 
         $this->load->view('Stud_view',$data); 
      } 
  
      public function delete_student() { 
         $this->load->model('Stud_Model'); 
         $user_id = $this->uri->segment('3'); 
		 $whre_clm="id=".$user_id;
		 	 $tbl="test";
         $this->Stud_Model->delete($whre_clm,$tbl); 
	
   
         $data['records'] = $this->Stud_Model->get_this($tbl); 
         $this->load->view('Stud_view',$data); 
      } 
	  public function exec_query(){
		  
		  $limit_val ="limit ". $this->uri->segment('3'); 
		  if($this->uri->segment('3')==null) $limit_val="";
		  $query="select * from test $limit_val";
		  
		  $this->load->model('Stud_Model');
		  
		  $data['records']=$this->Stud_Model->exec_query($query);
			$this->show_users($data);
			
		  
	  }
	  public function show_users($data){
		  $this->load->view('Stud_view',$data);
	  }
	  
	  public function login_user(){
	  
	 
	  $this->load->helper('form');
	  
	  
	  
	  $u_name=$this->input->post('user_name');
	  $u_pass=$this->input->post('pass_word');
	  
	   $data['succ']="";
	  if($u_name==null && $u_pass==null){

	 	$page_hint['my']=array('sts'=>'');

		$this->load->view('index',$page_hint);
	  }else{
	    $this->load->model('Stud_Model');
	  $query="select * from test where u_name='".$u_name."' and u_pass='".$u_pass."'";
	  
	 $user=$this->Stud_Model->exec_query($query);
	 if($user==null){

		$page_hint['my']=array('sts'=>'no users');
			$this->load->view('index',$page_hint);

	 }else{

	 	$this->load->library('session');
	 
	 	
	 	$user_id= $user[0]->id;
	 	$sess_vals=array(
	 		'id'=>$user_id
	 		);

	 	$this->session->set_userdata($sess_vals);
		if($this->session->has_userdata('id')){
			echo "login success";
			$page_hint['my']=array('sts'=>'');
			$this->load->view('file_upload',$page_hint);
		}else{
			echo "no sess";
		}

	 	

	 }
	  }
	  
	  
   }

   public function upload(){
   	  			$config['upload_path']          = '/uploads/';
                $config['allowed_types']        = 'gif|jpg|png|exe';
                $config['max_size']             = 100;
                $config['max_width']            = 1024;
                $config['max_height']           = 768;

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('userfile'))
                {
                        $error = array('error' => $this->upload->display_errors());
                       $page_hint['my']=$error;
                           
                        $this->load->view('file_upload', $page_hint);
                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());
                       $page_hint['my']=array('sts'=>'uploaded');

                        $this->load->view('file_upload', $page_hint);
                }
   } 


   }
   
?>