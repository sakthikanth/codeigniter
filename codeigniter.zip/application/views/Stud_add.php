<!DOCTYPE html> 
<html lang = "en">
 
   <head> 
      <meta charset = "utf-8"> 
      <title>Students Example</title> 
   </head> 
   <body> 
        
		
		<form method="post" action="http://localhost/codeigniter/index.php/stud/add">
			<div class="my">
				<label>Username</label><input type="text" name="user_name" />
			</div>
			<div class="my">
				<label>Userpass</label>	<input type="text" name="user_pass" />
			</div>
			<input type="submit" value="submit" />
			
		
		</form
   </body>
</html>