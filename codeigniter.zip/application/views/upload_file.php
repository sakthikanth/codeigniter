
<!DOCTYPE html>
<html>
<head>
	<title>403 Forbidden</title>
</head>
<body>


			
			<form action="../upload" method="post" >
			<div class="form" >
		
			<label>Upload File</label>
			<input type="file" value="" name="userfile" placeholder="name" />
			
			</div>

			<div>
			<input type="submit" value="Login" />
			</div>
			</form>
			</div>

</body>
</html>
