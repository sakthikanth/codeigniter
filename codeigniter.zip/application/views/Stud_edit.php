<!DOCTYPE html> 
<html lang = "en">
 
   <head> 
      <meta charset = "utf-8"> 
      <title>Students Example</title> 
   </head> 
	
   <body> 
      <form method = "post" action = "../../stud/update/<?php echo $records[0]->id; ?>">
		
         <div>
		Username <input type="text" name="username" value="<?php echo $records[0]->u_name; ?>" />
		 </div>
		  <div>
		 Password <input type="text" name="userpass" value="<?php echo $records[0]->u_pass; ?>" />
		 </div>
		 <div>
		 <input type="submit" value="Update" />
		 </div>
			
      </form> 
   </body>
	
</html>