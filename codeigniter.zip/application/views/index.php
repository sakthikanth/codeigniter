<!DOCTYPE html>
<html>
<head>
	<title>403 Forbidden</title>
</head>
<body>


			<div class="form" >
			<form action="../stud/login" method="post" >
			
			<div>
			<label>Username</label>
			<input type="text" value="" name="user_name" placeholder="name" />
			
			</div>
			<div>
			<label>Password</label>
			<input type="text" value="" name="pass_word" placeholder="name" />
			
			</div>

			<div>
			<label>Upload File</label>
			<input type="file" value="" name="userfile" placeholder="name" />
			
			</div>

			
			<?php 
			
			foreach ($my as $key => $value) {
					echo $value;
				}	
			 ?>
			<div>
			<input type="submit" value="Login" />
			</div>
			</form>
			</div>

</body>
</html>
