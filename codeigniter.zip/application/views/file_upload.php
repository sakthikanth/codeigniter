<!DOCTYPE html>
<html>
<head>
	<title>403 Forbidden</title>
</head>
<body>


			
			<form action="../stud/upload" method="post" enctype="multipart/form-data" >
			
			<div class="form" >
		
			<label>Upload File</label>
			<input type="file" value="" name="userfile" placeholder="name" />
			
			</div>

			
				<?php 
			
			foreach ($my as $key => $value) {
					echo $value;
				}	
			 ?>
			<div>
			<input type="submit" value="Upload" />
			</div>
			</form>
			</div>

</body>
</html>
