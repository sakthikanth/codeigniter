<!DOCTYPE html> 
<html lang = "en">
 
   <head> 
      <meta charset = "utf-8"> 
      <title>Students Example</title> 
   </head>
	
   <body> 
      <a href = "http://localhost/codeigniter/index.php/stud/add_view">Add</a>
		
      <table border = "1"> 
         <?php 
            $i = 1; 
            echo "<tr>"; 
            echo "<td>Sr#</td>"; 
            echo "<td>Uname.</td>"; 
            echo "<td>Upass</td>"; 
            echo "<td>Edit</td>"; 
            echo "<td>Delete</td>"; 
            echo "<tr>"; 
				
            foreach($records as $r) {
				
               echo "<tr>"; 
               echo "<td>".$i++."</td>"; 
               echo "<td>".$r->u_name."</td>"; 
               echo "<td>".$r->u_pass."</td>"; 
               echo "<td><a href = 'http://localhost/codeigniter/index.php/stud/edit/"
                  .$r->id."'>Edit</a></td>"; 
                echo "<td><a href = 'http://localhost/codeigniter/index.php/stud/delete/"
                  .$r->id."'>Delete</a></td>";
               echo "<tr>"; 
            } 
         ?>
      </table> 
      <?php echo phpinfo(); ?>
	  <a href="http://localhost/codeigniter/index.php/stud/exec/"><button >Execute</button></a>
		
   </body>
	
</html>