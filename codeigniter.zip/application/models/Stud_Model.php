<?php 
   class Stud_Model extends CI_Model {
	
      function __construct() { 
         parent::__construct(); 
      } 
   
   
      public function delete($whre_clm,$tbl) { 
         if ($this->db->delete($tbl, $whre_clm)) { 
            return true; 
         } 
      } 
   
      public function update($data,$old_roll_no) { 
         $this->db->set($data); 
         $this->db->where("id", $old_roll_no); 
         $this->db->update("test", $data); 
      } 
	  public function ins_q($data,$tbl){
		
		if($this->db->insert($tbl,$data)){
			return true;
			
		}
		
	  
	  }
	  
	  public function update_where($data,$whr_arr,$tbl){
	  
		$this->db->set($data); 
         $this->db->where($whr_arr); 
         $this->db->update($tbl, $data); 
		 
	  
	  }
	  
	  public function get_this($tbl){
	  
			$q=$this->db->get($tbl);
			return $q->result();
	  }
	  public function get_where($tbl,$arr){
		  $query = $this->db->get_where($tbl,$arr);
		  if($query->num_rows()>0){
		   return $query->result();
		  }else{
		  return null;
		  }
        
		  
	  }
	  public function exec_query($q){
	  
	  if($q=$this->db->query($q)){
			if($q->num_rows()>0){
			 return $q->result();
			}else{
			return null;
			}
	 
	  
	  }
		
	  }
   } 
?> 