<?php 
   Class User_model extends CI_Model { 
	
      Public function __construct() { 
         parent::__construct(); 
      } 
   } 
?> 